import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
import Footer from "./components/Footer";
import Header from "./components/Header";
import Homescreen from "./components/Screens/Homescreen";
import ProductScreen from "./components/Screens/ProductScreen";
import Login from "./components/Login";

function App() {
  return (

    <BrowserRouter>

      <div className="App">
        <Header />
        <main style={{minHeight:"835px"}} className="main">

          <Routes>
            <Route path="/" element={<Homescreen />} />
            <Route path="/product/:id" element={<ProductScreen />} />
            <Route path="/login" element={<Login />} />


          </Routes>


        </main>
        <Footer />
      </div>
    </BrowserRouter>
  );
}

export default App;
