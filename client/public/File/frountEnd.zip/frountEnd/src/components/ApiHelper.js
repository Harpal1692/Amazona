import axios from "axios";

class ApiHelper {
  constructor() {
    this.baseurl = "http://192.168.1.179:6001";
    // this.baseurl = "http://localhost:6001"
  }

  fetProducts() {
    return axios.get(`${this.baseurl}/api/product`);
  }

  Getproducts(id) {
    return axios.get(`${this.baseurl}/api/product/` + id);
  }
}

const apihelper = new ApiHelper();

export default apihelper;
