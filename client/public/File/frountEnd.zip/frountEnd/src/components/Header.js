function Header() {
  return (
    <header className="bg-dark px-3 d-flex justify-content-between align-items-center  text-light">
      <div className="logo">
        <a href="/" className="logo_first">
          <h3>amazon</h3>
        </a>
      </div>
      <div>
        <div className="d-flex align-items-center py-2 text-light gap-2">
          <span>cart</span>
          <button className="btn d-flex align-items-center justify-content-center   btn-warning fw-bold">
            sign in
          </button>
        </div>
      </div>
    </header>
  );
}
export default Header;
