import { useEffect, useState } from "react";
import Productcard from "./../Productcard";
import apihelper from "../ApiHelper";

export default function Homescreen() {
  const [products, setProducts] = useState([]);

  const GetProducts = async () => {
    try {
      const result = await apihelper.fetProducts();
      setProducts(result.data.products);
    } catch (error) {}
  };

  useEffect(() => {
    GetProducts();
  }, []);

  return (
    <div>
      {" "}
      <h3
        style={{
          paddingLeft: "19px",
          paddingTop: "18px",
          marginBottom: "-15px",
        }}
      >
        Feature Products
      </h3>
      <div className="container-fluid gap-4 d-flex flex.wrap py-4">
        <div className="d-flex pt-3 gap-4 flex-wrap justify-content-md-start justify-content-center">
          {products.map((product, index) => (
            <Productcard key={index} product={product} />
          ))}
        </div>
      </div>
    </div>
  );
}
