import React from 'react'

export default function Footer() {
  return (
    <footer>
        <div className='last_part bg-dark  text-light py-2 fw-bold fs-7'><center>All right reserved</center></div>
    </footer>
  )
}

