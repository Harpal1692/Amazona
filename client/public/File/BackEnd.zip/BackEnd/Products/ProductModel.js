const mongoose = require("mongoose")

class ProductModel{

    constructor(){
        this.schema = new mongoose.Schema({
            name:{type:String , require:true},
            image:{type:String , require:true},
            category:{type:String , require:true},
            alias:{type:String , require:true, unique:true},
            price:{type:Number , require:true},
            brand:{type:String , require:true},
            rating:{type:Number , require:true},
            stock:{type:Number , require:true},
            numReviews:{type:Number , require:true},
            description:{type:String , require:true},
        })
    }

}


const product =new ProductModel()
const productModel = mongoose.model("product",product.schema)

module.exports = productModel