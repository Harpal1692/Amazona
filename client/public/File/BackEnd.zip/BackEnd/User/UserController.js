const UserModel = require("./UserModel");
const bcrypt = require("bcrypt");
const Jwt = require("jsonwebtoken");
const userModel = require("./UserModel");

class UserController {
  async InsertUser(req, res) {
    try {
      const Password = bcrypt.hashSync(req.body.password, 8);

      console.log(Password);
      if (!Password) {
        return res.status(500).send({ message: "Something went wrong" });
      }

      let result = await UserModel.create({ ...req.body, password: Password });
      if (!result) {
        return res.status(500).send({ message: "Something went wrong" });
      }
      result = result._doc;
      delete result.password;
      return res.status(200).send({ message: "success", user: result });
    } catch (error) {
      if (error && error.code && error.code === 11000) {
        return res.status(400).send({ message: "email Allready exist" });
      }
      return res.status(500).send({ message: "Internal server error" });
    }
  }

  async UserLogin(req,res){

    try {
      const {email,password} = req.body
    
      let user = await userModel.findOne({email:email})
      if (!user)return res.status(400).send({message:"user not found"})
      
      user = user._doc.

      if (!(bcrypt.compareSync(password.user.password))) 

    } catch (error) {
      
    }
   

  }
}

const usercontroller = new UserController();

module.exports = usercontroller;
