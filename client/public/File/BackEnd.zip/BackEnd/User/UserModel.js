const mongoose = require("mongoose");

class UserModel{
    constructor(){
        this.schema = new mongoose.Schema({
            firstName:{type:String,require:true},
            lastName:{type:String,require:true},
            email:{type:String,require:true, unique:true},
            phone:{type:String,default:null},
            password:{type:String,require:true},
            isAdmin:{type:Boolean,default:false},
        },{
            timestamps:true
        })

        
    }


}


const user = new UserModel()

const userModel = mongoose.model("table_users",user.schema)

module.exports = userModel