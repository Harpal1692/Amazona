const express = require("express");
const Productcontroller = require("./Products/Productcontroller");
const cors = require("cors");
const connectDb = require("./Connection");
const usercontroller = require("./User/UserController");
connectDb();

const app = express();

app.use(express.json());
app.use(cors());

app.get("/", (req, res) => {
  return res.status(200).send({ message: "success" });
});

app.get("/api/product/InsertMany", Productcontroller.InsertProduct)

app.get("/api/product", Productcontroller.getproduct);

app.get("/api/product/:id", Productcontroller.getproductbyid);

app.post("/api/user", usercontroller.InsertUser);



app.listen(6001, () => {
  console.log("server stared");
});
